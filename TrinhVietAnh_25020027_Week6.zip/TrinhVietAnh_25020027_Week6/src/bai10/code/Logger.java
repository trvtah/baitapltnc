package bai10.code;

public class Logger {
    private static Logger instance;

    private Logger() {
    }

    public static Logger getInstance() {
        // Kiểm tra nếu chưa có thì mới tạo (Lazy Initialization)
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    public void logInfo(String msg) {
        System.out.println("[INFO] " + msg);
    }

    public void logError(String msg) {
        System.out.println("[ERROR] " + msg);
    }
}