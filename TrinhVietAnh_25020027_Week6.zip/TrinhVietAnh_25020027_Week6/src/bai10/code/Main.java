package bai10.code;

public class Main {
    public static void main(String[] args) {
        // Lấy đối tượng logger lần thứ nhất
        Logger logger1 = Logger.getInstance();

        // Lấy đối tượng logger lần thứ hai ở một nơi khác trong code
        Logger logger2 = Logger.getInstance();

        // Kiểm tra xem hai biến có cùng trỏ về một địa chỉ ô nhớ không
        System.out.println("Logger instances equal: " + (logger1 == logger2));

        logger1.logInfo("Application started");
        logger2.logInfo("Processing data...");
        logger1.logError("Something went wrong");

    }
}