package bai3.code;

public class Main {
    public static void main(String[] args) {
        String type = "win"; // hoặc "mac"

        UIFactory factory;

        if (type.equalsIgnoreCase("win")) {
            factory = new WindowsFactory();
        } else {
            factory = new MacFactory();
        }

        Button btn = factory.createButton();
        Checkbox cb = factory.createCheckbox();

        btn.render();
        cb.render();
    }
}