package bai7.code;

public interface Notifier {
    void send(String msg);
}
class EmailNotifier implements Notifier {
    @Override
    public void send(String msg) {
        System.out.println("Gửi Email với nội dung: " + msg);
    }
}
abstract class BaseDecorator implements Notifier {
    protected Notifier wrapper;

    public BaseDecorator(Notifier notifier) {
        this.wrapper = notifier;
    }

    @Override
    public void send(String msg) {
        wrapper.send(msg);
    }
}
// Decorator gửi SMS
class SMSNotifier extends BaseDecorator {
    public SMSNotifier(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String msg) {
        super.send(msg); // Gọi các kênh đã gắn trước đó
        System.out.println("Gửi SMS với nội dung: " + msg);
    }
}

// Decorator gửi Facebook
class FacebookNotifier extends BaseDecorator {
    public FacebookNotifier(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String msg) {
        super.send(msg); // Gọi các kênh đã gắn trước đó
        System.out.println("Gửi thông báo Facebook với nội dung: " + msg);
    }
}