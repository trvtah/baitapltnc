package bai7.code;

public class Main {
    public static void main(String[] args) {
        System.out.println("--- Trường hợp 1: Chỉ gửi Email ---");
        Notifier simple = new EmailNotifier();
        simple.send("Chào bạn!");

        System.out.println("\n--- Trường hợp 2: Email + Facebook ---");
        Notifier fbEnabled = new FacebookNotifier(new EmailNotifier());
        fbEnabled.send("Chào bạn!");

        System.out.println("\n--- Trường hợp 3: Email + Facebook + SMS ---");
        // Lồng 3 lớp: SMS bọc Facebook, Facebook bọc Email
        Notifier multiChannel = new SMSNotifier(
                new FacebookNotifier(
                        new EmailNotifier()
                )
        );

        multiChannel.send("Hệ thống có thông báo mới!");
    }
}