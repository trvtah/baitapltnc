package bai6.code;

public class Main {
    public static void main(String[] args) {
        Folder root = new Folder("root");

        Folder docs = new Folder("docs");

        // Tạo các file trong docs
        FileItem aText = new FileItem("a.txt", 12);
        FileItem bText = new FileItem("b.txt", 8);

        docs.addComponent(aText);
        docs.addComponent(bText);

        // Tạo Shortcut trỏ đến a.txt
        Shortcut aShortcut = new Shortcut("a-shortcut", aText, "/root/docs/a.txt");
        docs.addComponent(aShortcut);

        //  Thêm thư mục 'docs' và file lẻ vào 'root'
        root.addComponent(docs);
        root.addComponent(new FileItem("readme.md", 4));

        root.print("");
    }
}