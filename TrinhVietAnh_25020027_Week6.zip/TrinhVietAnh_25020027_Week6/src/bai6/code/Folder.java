package bai6.code;

import java.util.ArrayList;
import java.util.List;

public class Folder extends FileSystemItem {
    private List<FileSystemItem> children = new ArrayList<>();

    public Folder(String name) {
        super(name);
    }

    public void addComponent(FileSystemItem item) {
        children.add(item);
    }

    @Override
    public void print(String indent) {
        System.out.println(indent + "Folder: " + name);
        // Mỗi khi vào thư mục con,  tăng khoảng cách đầu dòng
        for (FileSystemItem item : children) {
            item.print(indent + "  ");
        }
    }
}