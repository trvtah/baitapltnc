package bai4b.code;

import java.util.ArrayList;
import java.util.List;

public class ReportTemplate implements Cloneable {
    private String title;
    private String footer;
    private List<String> sections;

    public ReportTemplate(String title, String footer, List<String> sections) {
        this.title = title;
        this.footer = footer;
        this.sections = sections;
    }

    // Getter và setter để chỉnh sửa bản sao
    public void setTitle(String title) { this.title = title; }
    public String getTitle() { return title; }

    @Override
    public String toString() {
        return "Report [Title: " + title + ", Footer: " + footer + ", Sections: " + sections + "]";
    }

// Ghi đè phương thức clone()
    @Override
    public ReportTemplate clone() {
        try {
            ReportTemplate cloned = (ReportTemplate) super.clone();
            cloned.sections = new ArrayList<>(this.sections);
            return cloned;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}