package bai4b.code;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // 1. Tạo một template gốc
        ReportTemplate original = new ReportTemplate(
                "Báo cáo tháng 01",
                "Bản quyền thuộc về Công ty ABC",
                Arrays.asList("Mục lục", "Nội dung chính", "Kết luận")
        );

        // 2. Sinh ra bản sao thứ nhất và chỉnh sửa tiêu đề
        ReportTemplate copy1 = original.clone();
        copy1.setTitle("Báo cáo tháng 02 (Bản sao 1)");

        // 3. Sinh ra bản sao thứ hai và chỉnh sửa tiêu đề
        ReportTemplate copy2 = original.clone();
        copy2.setTitle("Báo cáo tháng 03 (Bản sao 2)");

        // 4. In ra để kiểm tra tính độc lập
        System.out.println("Gốc:  " + original);
        System.out.println("Copy 1: " + copy1);
        System.out.println("Copy 2: " + copy2);

        // Kiểm tra xem địa chỉ bộ nhớ có khác nhau không
        System.out.println("\nKiểm tra độc lập: " + (original != copy1));
    }
}