package bai2.code;

public abstract class NotificationApp {

    // Abstract factory method
    protected abstract Notification createNotification();

    // Logic dùng chung
    public void notifyUser(String msg) {
        Notification notification = createNotification();
        notification.send(msg);
    }
}

class EmailApp extends NotificationApp {
    @Override
    protected Notification createNotification() {
        return new EmailNotification(); // Tạo sản phẩm Email
    }
}

class SmsApp extends NotificationApp {
    @Override
    protected Notification createNotification() {
        return new SmsNotification(); // Tạo sản phẩm SMS
    }
}