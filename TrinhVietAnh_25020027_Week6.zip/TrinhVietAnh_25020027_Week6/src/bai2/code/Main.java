package bai2.code;

public class Main {
    public static void main(String[] args) {

        // Sử dụng ứng dụng Email
        NotificationApp myEmailApp = new EmailApp();
        myEmailApp.notifyUser("Mã xác nhận của bạn là 998877 (Gửi qua Email).");

        System.out.println("--------------------------------------------");

        // Sử dụng ứng dụng SMS
        NotificationApp mySmsApp = new SmsApp();
        mySmsApp.notifyUser("Tài khoản của bạn vừa có biến động số dư (Gửi qua SMS).");
    }
}