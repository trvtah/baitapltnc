package bai9.code;

public class Main {
    public static void main(String[] args) {
        // Tạo các thành phần cụ thể bên ngoài
        AudioPlayable myAudioDevice = new AudioPlayer();
        VideoPlayable myVideoDevice = new VideoPlayer();

        // Inject chúng vào MediaPlayer
        MediaPlayer mySystem = new MediaPlayer(myAudioDevice, myVideoDevice);

        System.out.println("--- Hệ thống bắt đầu chạy ---");
        mySystem.playAudio("nhac_chill.mp3");
        mySystem.playVideo("phim_hanh_dong.mp4");
    }
}