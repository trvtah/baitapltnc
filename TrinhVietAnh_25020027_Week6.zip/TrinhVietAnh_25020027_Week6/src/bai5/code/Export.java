package bai5.code;

interface Export {
    void exportFile();
}

class PdfExport implements Export {
    public void exportFile() { System.out.println("Đang xuất file PDF..."); }
}

class ExcelExport implements Export {
    public void exportFile() { System.out.println("Đang xuất file Excel..."); }
}

class ExportFactory {
    public static Export createExport(String type) {
        if (type.equalsIgnoreCase("PDF")) return new PdfExport();
        else if (type.equalsIgnoreCase("EXCEL")) return new ExcelExport();
        return null;
    }
}