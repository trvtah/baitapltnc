package bai5.code;

public class Main {
    public static void main(String[] args) {
        // 1. Kiểm tra Singleton
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();
        System.out.println("Singleton: " + (logger1 == logger2)); // Kết quả: true

        // 2. Kiểm tra Factory Method
        Export pdf = ExportFactory.createExport("PDF");
        pdf.exportFile();

        // 3. Kiểm tra Adapter
        OldPlayer old = new OldPlayer();
        Player player = new PlayerAdapter(old);
        player.play("Nhạc_Trẻ.mp3");

        // 4. Kiểm tra Prototype
        Config originalConfig = new Config("Server_Goc");
        Config copyConfig = originalConfig.clone();
        copyConfig.setServerName("Server_Sao_Chep");

        System.out.println("Gốc: " + originalConfig);
        System.out.println("Bản sao: " + copyConfig);
    }
}