package bai5.code;

public class Config implements Cloneable {
    private String serverName;

    public Config(String serverName) { this.serverName = serverName; }
    public void setServerName(String name) { this.serverName = name; }

    @Override
    public String toString() { return "Config [Server: " + serverName + "]"; }

    @Override
    public Config clone() {
        try {
            return (Config) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}