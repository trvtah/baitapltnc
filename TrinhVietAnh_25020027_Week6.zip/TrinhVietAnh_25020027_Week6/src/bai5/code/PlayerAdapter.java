package bai5.code;

// Lớp cũ không được sửa
class OldPlayer {
    void playFile(String name) {
        System.out.println("Đang chơi file: " + name + " bằng OldPlayer");
    }
}

// Interface mới
interface Player {
    void play(String name);
}

// Bộ chuyển đổi
class PlayerAdapter implements Player {
    private OldPlayer oldPlayer;

    public PlayerAdapter(OldPlayer oldPlayer) {
        this.oldPlayer = oldPlayer;
    }

    @Override
    public void play(String name) {
        // Chuyển đổi từ play() sang playFile()
        oldPlayer.playFile(name);
    }
}