package bai1.code;

public class AppConfig {
    // Biến instance tĩnh, dùng 'volatile' để đảm bảo các luồng đọc giá trị chính xác nhất
    private static volatile AppConfig instance;

    // Các thuộc tính của cấu hình
    private String appName;
    private String version;
    private String logLevel;

    // Constructor private: Ngăn chặn khởi tạo từ bên ngoài
    private AppConfig() {
        this.appName = "My Awesome App";
        this.version = "1.0.0";
        this.logLevel = "DEBUG";

        // Giả lập thời gian khởi tạo tốn kém
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Phương thức getInstance an toàn đa luồng (Double-Checked Locking)
    public static AppConfig getInstance() {
        if (instance == null) {
            synchronized (AppConfig.class) {
                if (instance == null) {
                    instance = new AppConfig();
                }
            }
        }
        return instance;
    }

    // Getter
    public String getAppName() { return appName; }
    public String getVersion() { return version; }
    public String getLogLevel() { return logLevel; }
}
