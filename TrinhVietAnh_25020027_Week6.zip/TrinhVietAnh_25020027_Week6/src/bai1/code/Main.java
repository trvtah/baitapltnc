package bai1.code;

public class Main {
    public static void main(String[] args) {

        // Định nghĩa công việc cho mỗi luồng
        Runnable task = () -> {
            AppConfig config = AppConfig.getInstance();
            System.out.println("Luồng [" + Thread.currentThread().getName() +
                    "] - HashCode: " + config.hashCode());
        };

        // Tạo 2 luồng riêng biệt
        Thread t1 = new Thread(task, "Thread-1");
        Thread t2 = new Thread(task, "Thread-2");

        // Bắt đầu chạy
        t1.start();
        t2.start();

        // Chờ các luồng kết thúc để in dòng thông báo cuối
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("\nLưu ý: Nếu 2 HashCode giống hệt nhau, nghĩa là chỉ có 1 đối tượng duy nhất!");
    }
}