package bai4a.code;

import java.util.Arrays;

interface Sorter {
    int[] sort(int[] arr);
}

class LegacySorter {
    public int[] quickSort(int[] arr) {
        // Giả lập thuật toán sắp xếp của thư viện cũ
        Arrays.sort(arr);
        System.out.println("Đang dùng thuật toán QuickSort từ Legacy library...");
        return arr;
    }
}

class SorterAdapter implements Sorter {
    private LegacySorter legacySorter;

    public SorterAdapter(LegacySorter legacySorter) {
        this.legacySorter = legacySorter;
    }

    @Override
    public int[] sort(int[] arr) {
        // Khi hệ thống gọi .sort(), Adapter sẽ bí mật gọi .quickSort() của thư viện cũ
        return legacySorter.quickSort(arr);
    }
}

class Main {
    public static void main(String[] args) {
        // Khởi tạo dữ liệu mẫu
        int[] data = {5, 2, 9, 1, 3};
        System.out.println("Mảng ban đầu: " + Arrays.toString(data));

        // Khởi tạo thư viện cũ và bộ chuyển đổi
        LegacySorter oldLib = new LegacySorter();
        Sorter sorter = new SorterAdapter(oldLib);

        // Hệ thống gọi thông qua interface Sorter
        int[] result = sorter.sort(data);

        // In kết quả
        System.out.println("Mảng sau khi sắp xếp: " + Arrays.toString(result));
    }
}