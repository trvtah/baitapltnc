package bai8.code;

public interface ReportFormatter {
    String format(Report data);
}