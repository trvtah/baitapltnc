package bai8.code;

public class JsonFormatter implements ReportFormatter {
    @Override
    public String format(Report data) {
        return "{\n  \"title\": \"" + data.getTitle() + "\",\n  \"content\": \"" + data.getContent() + "\"\n}";
    }
}
class XmlFormatter implements ReportFormatter {
    @Override
    public String format(Report data) {
        return "<report>\n  <title>" + data.getTitle() + "</title>\n  <content>" + data.getContent() + "</content>\n</report>";
    }
}