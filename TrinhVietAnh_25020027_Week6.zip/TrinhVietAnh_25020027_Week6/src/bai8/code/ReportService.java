package bai8.code;

public class ReportService {
    private ReportFormatter formatter;

    public ReportService(ReportFormatter formatter) {
        this.formatter = formatter;
    }

    public String export(Report data) {
        // ReportService không biết chi tiết định dạng, nó chỉ yêu cầu formatter làm việc
        return formatter.format(data);
    }
}