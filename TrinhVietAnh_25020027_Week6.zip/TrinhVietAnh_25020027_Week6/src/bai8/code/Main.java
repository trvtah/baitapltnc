package bai8.code;

public class Main {
    public static void main(String[] args) {
        Report myReport = new Report("Báo cáo tháng 4", "Nội dung doanh thu...");

        // Muốn xuất JSON
        ReportService jsonService = new ReportService(new JsonFormatter());
        System.out.println(" KẾT QUẢ JSON ");
        System.out.println(jsonService.export(myReport));

        // Muốn xuất XML
        ReportService xmlService = new ReportService(new XmlFormatter());
        System.out.println("\nKẾT QUẢ XML ");
        System.out.println(xmlService.export(myReport));
    }
}